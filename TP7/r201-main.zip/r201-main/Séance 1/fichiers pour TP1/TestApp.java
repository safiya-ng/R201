/**
 *  premier programme java
 */


public class TestApp
{
  public static void main(String[] args)	{
	
        System.out.println("Bonjour tout le monde !");
	
   }	// fin du main
}// fin de la classe TestApp
