public class Ampoule {


	public Ampoule() {

	}

	public Ampoule(int couleur, int puissance) {

	}
	public Ampoule(Ampoule a) {

	}

	public void allumer() {

	}

	public void eteindre() {

	}

	public int getCouleur() {

	}

	public void setCouleur(int couleur) {

	}

	public int getPuissance() {

	}

	public void setPuissance(int puissance) {

	}

	public String toString() {
		
	}
}
