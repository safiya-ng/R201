public class TestAmpoule {

	public static void main(String[] args) {

	}
}
