/******************** Test de la classe *****************************/

public class TestCompteBancaire
{

public static void main(String args[]) {

}// fin du main
} // fin de la classe

