
/**
 *  teste la classe Recipient
 *
 */

public class TestRecipient
{

	public static void main(String[] args)
	{


		}

		 // fin main

} // fin class TestRecipient
