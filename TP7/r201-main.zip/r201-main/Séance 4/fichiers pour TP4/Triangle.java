import java.awt.*;

public class Triangle	{
// variable d'instance
private Point[] sommets ;

// ào compléter
public Triangle(){
}

public Triangle(Point p1, Point p2, Point p3)	{

}

public Triangle(Point[] tabPoints)	{
}

public void setPoint(Point p, int i) {

}

public Point getPoint(int i) {
	
}
public String toString()	{
	
}

public void translate(int dx, int dy)	{

}

}

