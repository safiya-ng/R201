/**Fichier AgenceBancaire.java
* utilisation de classe Java ArrayList
*/
   import java.util.*;

   public class AgenceBancaire {
      private String nomAgence; 	//nom de l'agence
      private String ville; //adresse de l'agence

      private ArrayList<CompteBancaire> ensComptesBancaires; // ensembles des comptes bancaires de l'agence


   /**
   * Constructeur
   */

      public AgenceBancaire(String nom,String adresse){

      }



   /* pour affichage ***************************************************/

       public String toString() {

	}

   /* Gestion des comptes *****************************************/
   public void add(CompteBancaire cb)  {

	}


      public boolean compteExiste(CompteBancaire cb)  {

      }

      public ArrayList<CompteBancaire> lesComptesDe(String nom)  {

      }


   //test de la classe************


   }//fin classe
