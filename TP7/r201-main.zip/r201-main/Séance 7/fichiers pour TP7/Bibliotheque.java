import java.util.ArrayList;
import java.util.ListIterator;

public class Bibliotheque {
    private String nom ;
    private ArrayList<Livre> livres ;
    private int numero ;

    public Bibliotheque(String unNom){

    }
    public void ajouterLivre(Livre livre) {

    }
    public String getNom() {

    }
    public void setNom(String nom) {

    }
    public Livre chercherLivre(int num) {
        ListIterator<Livre> i ...
    }
    public void retirerLivre(Livre l) {

    }
    public void retirerLivre(int num) {
        ListIterator<Livre> i ...
    }

    public String toString() {

    }

    public static void main(String[] args)
    {
        
    }
}
