import java.util.ArrayList;

/**
 *  utilisation de classes existantes : pour le Tp sur les listes
 *  @author Françoise GAYRAL
 */

public class TestBanque
{
  public static void main(String[] args)	{
	CompteBancaire cb1,cb2,.....
	cb1=new CompteBancaire("toto",3000f,"765TR");
		......

   }	// fin du main
}// fin de la classe TestBanque
